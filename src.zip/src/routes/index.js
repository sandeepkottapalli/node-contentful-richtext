import contentful from './contentful';

export default {
  contentful,
};
