import { v4 as uuidv4 } from 'uuid';
import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  const { parseHtml } = require('contentful-html-rich-text-converter');

  const html = '<ul><li><p>a</p></li><li><p>b</p></li><li><p>c</p></li></ul><p></p>';
  const result = parseHtml(html);
  return res.send(result);
});


router.post('/htmltomarkdown', (req, res) => {
  const { parseHtml } = require('contentful-html-rich-text-converter');
  const html = req.body.text;
  const result = parseHtml(html);
  return res.send(result);
});

// router.post('/markdowntohtml', (req, res) => {
//   const { documentToHtmlString } = require('contentful-html-rich-text-converter');
//   const document = req.body.text;
//   const result = documentToHtmlString(document);
//   return res.send(result);
// });



export default router;
